from django.shortcuts import render,HttpResponse
from nittmart2020.models import Registerbuyer
from nittmart2020.models import Registerseller
from django.contrib.auth import authenticate, login


from django.contrib.auth.models  import User, auth




# Create your views here.
def index(request):
    return render(request,'homepage.HTML')

def registeration(request):
    return render(request,'registeration.html')

def loginpage(request):
    return render(request,'login.html')



def handlelogin(request):
    if request.method =="POST":
        loginid = request.POST['loginid']
        loginpassword= request.POST['loginpassword']

        user = authenticate(request,email=loginid,password=loginpassword)

        if user is not None:
            login(request,user)
            return HttpResponse("WELCOME")
        else:
            return HttpResponse("invalid")

    else:
        return render(request,'login.html')

def handleloginsell(request):
    if request.method =="POST":
        loginid = request.POST['loginid']
        loginpassword= request.POST['loginpassword']

        user = authenticate(email=loginid,password=loginpassword)

        if user is not None:
            login(request,user)
            return HttpResponse("WELCOME")
        else:
            return HttpResponse("invalid")

    else:
        return render(request,'login.html')

def register(request):
    if request.method =="POST":
        firstname = request.POST.get('firstname')
        email = request.POST.get('email')
        password= request.POST.get('password')
       
        
        
        

        kp = Registerbuyer(firstname = firstname,email = email, password= password)
        kp.save()

    return HttpResponse("Registered Succesfully")


def registersell(request):
    if request.method =="POST":
        firstname = request.POST.get('firstname')
        email = request.POST.get('email')
        password= request.POST.get('password')
       
        
        
        

        kp = Registerseller(firstname = firstname,email = email, password= password)
        kp.save()

    return HttpResponse("Registered Succesfully")