from django.apps import AppConfig


class Nittmart2020Config(AppConfig):
    name = 'nittmart2020'
