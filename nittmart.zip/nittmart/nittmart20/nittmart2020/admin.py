from django.contrib import admin
from nittmart2020.models import Registerbuyer
from nittmart2020.models import Registerseller

# Register your models here.
admin.site.register(Registerbuyer)
admin.site.register(Registerseller)